using UnityEngine;

// The coin spins and bobs up and down, and is collected when the player touches it.
public class CoinPickup : MonoBehaviour
{
    public float spinSpeed = 120f;
    public float bobHeight = 0.15f;
    public float bobSpeed = 2f;

    Vector3 basePosition;
    float phase;

    void Start()
    {
        basePosition = transform.position;
        phase = Random.value * 6.28f;
    }

    void Update()
    {
        transform.Rotate(0f, spinSpeed * Time.deltaTime, 0f, Space.World);
        transform.position = basePosition + Vector3.up * (Mathf.Sin(Time.time * bobSpeed + phase) * bobHeight);
    }

    void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Player")) return;

        if (GameManager.Instance != null) GameManager.Instance.AddCoin();
        Destroy(gameObject);
    }
}

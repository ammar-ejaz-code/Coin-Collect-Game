using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;

// When the project is opened for the first time, this script builds the whole 3D scene
// automatically (ground, walls, platforms, coins, player, camera, light).
// To rebuild it later, use the menu: Tools > Coin Game > Build Scene
[InitializeOnLoad]
public static class SceneBuilder
{
    const string ScenePath = "Assets/Scenes/Main.unity";

    static SceneBuilder()
    {
        EditorApplication.delayCall += () =>
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode) return;
            if (!File.Exists(ScenePath)) Build(false);
        };
    }

    [MenuItem("Tools/Coin Game/Build Scene")]
    public static void BuildFromMenu()
    {
        Build(true);
    }

    static void Build(bool askToSave)
    {
        if (askToSave && !EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;

        Directory.CreateDirectory("Assets/Scenes");
        Directory.CreateDirectory("Assets/Materials");
        AssetDatabase.Refresh();

        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

        // Materials
        Material groundMat = MakeMaterial("Ground", new Color(0.35f, 0.58f, 0.36f), 0f, 0.1f);
        Material wallMat = MakeMaterial("Wall", new Color(0.55f, 0.42f, 0.32f), 0f, 0.1f);
        Material platformMat = MakeMaterial("Platform", new Color(0.35f, 0.42f, 0.78f), 0f, 0.2f);
        Material playerMat = MakeMaterial("Player", new Color(0.92f, 0.25f, 0.2f), 0f, 0.6f);
        Material coinMat = MakeMaterial("Coin", new Color(1f, 0.82f, 0.1f), 0.8f, 0.7f);

        // Scene look
        RenderSettings.ambientMode = AmbientMode.Flat;
        RenderSettings.ambientLight = new Color(0.55f, 0.58f, 0.65f);

        // Light
        var lightGo = new GameObject("Directional Light");
        var light = lightGo.AddComponent<Light>();
        light.type = LightType.Directional;
        light.intensity = 1.1f;
        light.shadows = LightShadows.Soft;
        lightGo.transform.rotation = Quaternion.Euler(50f, -30f, 0f);
        RenderSettings.sun = light;

        // Environment
        var env = new GameObject("Environment").transform;
        MakeBox("Ground", new Vector3(0f, -0.5f, 0f), new Vector3(40f, 1f, 40f), groundMat, env);

        MakeBox("Wall North", new Vector3(0f, 1f, 20.5f), new Vector3(42f, 2f, 1f), wallMat, env);
        MakeBox("Wall South", new Vector3(0f, 1f, -20.5f), new Vector3(42f, 2f, 1f), wallMat, env);
        MakeBox("Wall East", new Vector3(20.5f, 1f, 0f), new Vector3(1f, 2f, 40f), wallMat, env);
        MakeBox("Wall West", new Vector3(-20.5f, 1f, 0f), new Vector3(1f, 2f, 40f), wallMat, env);

        // Platforms to jump on, and one barrier
        MakeBox("Platform 1", new Vector3(8f, 0.5f, 8f), new Vector3(5f, 1f, 5f), platformMat, env);
        MakeBox("Platform 2", new Vector3(13f, 1f, 13f), new Vector3(4f, 2f, 4f), platformMat, env);
        MakeBox("Platform 3", new Vector3(-9f, 0.5f, -8f), new Vector3(5f, 1f, 5f), platformMat, env);
        MakeBox("Platform 4", new Vector3(-14f, 1f, -13f), new Vector3(4f, 2f, 4f), platformMat, env);
        MakeBox("Barrier", new Vector3(0f, 0.5f, 6f), new Vector3(8f, 1f, 1f), platformMat, env);

        // Coins
        var coins = new GameObject("Coins").transform;
        Vector3[] coinPositions =
        {
            // on the ground
            new Vector3(5f, 1f, 0f),
            new Vector3(10f, 1f, -6f),
            new Vector3(16f, 1f, -14f),
            new Vector3(0f, 1f, 9f),
            new Vector3(-6f, 1f, 16f),
            new Vector3(-16f, 1f, 6f),
            new Vector3(-17f, 1f, -3f),
            new Vector3(3f, 1f, -11f),
            new Vector3(-4f, 1f, -16f),
            new Vector3(16f, 1f, 3f),
            new Vector3(-12f, 1f, 12f),
            // on top of the platforms
            new Vector3(8f, 2f, 8f),
            new Vector3(13f, 3f, 13f),
            new Vector3(-9f, 2f, -8f),
            new Vector3(-14f, 3f, -13f)
        };
        foreach (Vector3 p in coinPositions) MakeCoin(p, coinMat, coins);

        // Player
        var player = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        player.name = "Player";
        player.tag = "Player";
        player.transform.position = new Vector3(0f, 1f, 0f);
        player.GetComponent<Renderer>().sharedMaterial = playerMat;
        var rb = player.AddComponent<Rigidbody>();
        rb.mass = 1f;
        player.AddComponent<PlayerController>();

        // Camera
        var camGo = new GameObject("Main Camera");
        camGo.tag = "MainCamera";
        var cam = camGo.AddComponent<Camera>();
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.backgroundColor = new Color(0.53f, 0.75f, 0.95f);
        camGo.AddComponent<AudioListener>();
        camGo.transform.position = new Vector3(0f, 6f, -8f);
        camGo.transform.rotation = Quaternion.Euler(30f, 0f, 0f);
        var follow = camGo.AddComponent<CameraFollow>();
        follow.target = player.transform;

        // Game manager
        new GameObject("GameManager").AddComponent<GameManager>();

        // Save
        EditorSceneManager.SaveScene(scene, ScenePath);
        AssetDatabase.SaveAssets();
        EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };

        Debug.Log("Coin Game scene created: " + ScenePath + ". Press the Play button!");
    }

    static GameObject MakeBox(string name, Vector3 position, Vector3 scale, Material mat, Transform parent)
    {
        var go = GameObject.CreatePrimitive(PrimitiveType.Cube);
        go.name = name;
        go.transform.SetParent(parent, false);
        go.transform.position = position;
        go.transform.localScale = scale;
        go.GetComponent<Renderer>().sharedMaterial = mat;
        return go;
    }

    static void MakeCoin(Vector3 position, Material mat, Transform parent)
    {
        var root = new GameObject("Coin");
        root.transform.SetParent(parent, false);
        root.transform.position = position;

        var trigger = root.AddComponent<SphereCollider>();
        trigger.isTrigger = true;
        trigger.radius = 0.7f;
        root.AddComponent<CoinPickup>();

        var visual = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        visual.name = "Visual";
        Object.DestroyImmediate(visual.GetComponent<Collider>());
        visual.transform.SetParent(root.transform, false);
        visual.transform.localRotation = Quaternion.Euler(0f, 0f, 90f);
        visual.transform.localScale = new Vector3(0.7f, 0.06f, 0.7f);
        visual.GetComponent<Renderer>().sharedMaterial = mat;
    }

    static Material MakeMaterial(string name, Color color, float metallic, float smoothness)
    {
        string path = "Assets/Materials/" + name + ".mat";
        var existing = AssetDatabase.LoadAssetAtPath<Material>(path);
        if (existing != null) return existing;

        Shader shader = Shader.Find("Standard");
        if (shader == null) shader = Shader.Find("Universal Render Pipeline/Lit");
        if (shader == null) shader = Shader.Find("Sprites/Default");

        var mat = new Material(shader);
        mat.color = color;
        if (mat.HasProperty("_Metallic")) mat.SetFloat("_Metallic", metallic);
        if (mat.HasProperty("_Glossiness")) mat.SetFloat("_Glossiness", smoothness);
        if (mat.HasProperty("_Smoothness")) mat.SetFloat("_Smoothness", smoothness);

        AssetDatabase.CreateAsset(mat, path);
        return mat;
    }
}

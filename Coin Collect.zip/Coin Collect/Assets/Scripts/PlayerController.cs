using UnityEngine;

// Move the ball with WASD / Arrow keys and jump with Space.
[RequireComponent(typeof(Rigidbody))]
public class PlayerController : MonoBehaviour
{
    public float moveAcceleration = 22f;
    public float maxSpeed = 9f;
    public float jumpSpeed = 6.5f;

    Rigidbody rb;
    Transform cam;
    Vector3 startPosition;
    bool jumpQueued;

    Vector3 Velocity
    {
#if UNITY_6000_0_OR_NEWER
        get { return rb.linearVelocity; }
#else
        get { return rb.velocity; }
#endif
    }

    void Awake()
    {
        rb = GetComponent<Rigidbody>();
        startPosition = transform.position;

        rb.collisionDetectionMode = CollisionDetectionMode.Continuous;
        rb.interpolation = RigidbodyInterpolation.Interpolate;
#if UNITY_6000_0_OR_NEWER
        rb.linearDamping = 0.4f;
        rb.angularDamping = 1.5f;
#else
        rb.drag = 0.4f;
        rb.angularDrag = 1.5f;
#endif
    }

    void Start()
    {
        if (Camera.main != null) cam = Camera.main.transform;
    }

    void Update()
    {
        if (Input.GetButtonDown("Jump")) jumpQueued = true;

        // If the player falls off the arena, go back to the start
        if (transform.position.y < -10f) Respawn();
    }

    void FixedUpdate()
    {
        float h = Input.GetAxisRaw("Horizontal");
        float v = Input.GetAxisRaw("Vertical");

        Vector3 forward = Vector3.forward;
        Vector3 right = Vector3.right;
        if (cam != null)
        {
            forward = Vector3.ProjectOnPlane(cam.forward, Vector3.up).normalized;
            right = Vector3.ProjectOnPlane(cam.right, Vector3.up).normalized;
        }

        Vector3 direction = forward * v + right * h;
        if (direction.sqrMagnitude > 1f) direction.Normalize();

        Vector3 flat = new Vector3(Velocity.x, 0f, Velocity.z);
        bool belowMax = flat.magnitude < maxSpeed;
        bool braking = Vector3.Dot(flat, direction) < 0f;
        if (belowMax || braking)
        {
            rb.AddForce(direction * moveAcceleration, ForceMode.Acceleration);
        }

        if (jumpQueued && IsGrounded())
        {
            rb.AddForce(Vector3.up * jumpSpeed, ForceMode.VelocityChange);
        }
        jumpQueued = false;
    }

    bool IsGrounded()
    {
        return Physics.Raycast(transform.position, Vector3.down, 0.62f);
    }

    public void Respawn()
    {
        rb.position = startPosition;
        transform.position = startPosition;
#if UNITY_6000_0_OR_NEWER
        rb.linearVelocity = Vector3.zero;
#else
        rb.velocity = Vector3.zero;
#endif
        rb.angularVelocity = Vector3.zero;
    }
}

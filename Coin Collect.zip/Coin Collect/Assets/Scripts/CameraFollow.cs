using UnityEngine;

// The camera follows behind the player. Press Q / E to rotate it.
public class CameraFollow : MonoBehaviour
{
    public Transform target;
    public Vector3 offset = new Vector3(0f, 6f, -8f);
    public float followSpeed = 6f;
    public float rotateSpeed = 90f;

    float yaw;

    void LateUpdate()
    {
        if (target == null) return;

        if (Input.GetKey(KeyCode.Q)) yaw -= rotateSpeed * Time.deltaTime;
        if (Input.GetKey(KeyCode.E)) yaw += rotateSpeed * Time.deltaTime;

        Vector3 desired = target.position + Quaternion.Euler(0f, yaw, 0f) * offset;
        transform.position = Vector3.Lerp(transform.position, desired, followSpeed * Time.deltaTime);
        transform.LookAt(target.position + Vector3.up * 0.5f);
    }
}

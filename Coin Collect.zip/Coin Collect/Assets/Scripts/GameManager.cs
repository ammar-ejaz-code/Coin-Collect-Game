
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }

    int totalCoins;
    int collected;
    float elapsed;
    bool won;
    bool gameOver;

    const float timeLimit = 60f;

    GUIStyle scoreStyle;
    GUIStyle hintStyle;
    GUIStyle winStyle;

    void Awake()
    {
        Instance = this;
    }

    void Start()
    {
        totalCoins = FindObjectsByType<CoinPickup>(
            FindObjectsSortMode.None).Length;
    }

    void Update()
    {
        // Stop the timer after winning or losing
        if (!won && !gameOver)
        {
            elapsed += Time.deltaTime;

            if (elapsed >= timeLimit)
            {
                elapsed = timeLimit;
                gameOver = true;
            }
        }

        // Restart the level
        if (Input.GetKeyDown(KeyCode.R))
        {
            SceneManager.LoadScene(
                SceneManager.GetActiveScene().buildIndex);
        }
    }

    public void AddCoin()
    {
        // Do not collect more coins after the game ends
        if (won || gameOver)
            return;

        collected++;

        if (collected >= totalCoins)
        {
            // Win only if the time limit has not expired
            if (elapsed < timeLimit)
                won = true;
            else
                gameOver = true;
        }
    }

    void OnGUI()
    {
        if (scoreStyle == null)
        {
            scoreStyle = new GUIStyle(GUI.skin.label)
            {
                fontSize = 28,
                fontStyle = FontStyle.Bold
            };
            scoreStyle.normal.textColor = Color.white;

            hintStyle = new GUIStyle(GUI.skin.label)
            {
                fontSize = 18
            };
            hintStyle.normal.textColor = Color.white;

            winStyle = new GUIStyle(GUI.skin.label)
            {
                fontSize = 26,
                fontStyle = FontStyle.Bold,
                alignment = TextAnchor.MiddleCenter,
                richText = true,
                wordWrap = true
            };
            winStyle.normal.textColor =
                new Color(1f, 0.85f, 0.2f);
        }

        // Score and countdown timer
        DrawPanel(new Rect(10, 10, 300, 85));

        DrawText(
            new Rect(20, 14, 280, 40),
            "Coins: " + collected + " / " + totalCoins,
            scoreStyle);

        float timeLeft = Mathf.Max(0f, timeLimit - elapsed);

        DrawText(
            new Rect(20, 55, 280, 30),
            "Time Left: " + timeLeft.ToString("0.0") + " s",
            hintStyle);

        // Controls
        DrawPanel(new Rect(
            0, Screen.height - 40, Screen.width, 40));

        DrawText(
            new Rect(15, Screen.height - 34,
                Screen.width - 30, 30),
            "WASD / Arrows = Move   |   Space = Jump   |   Q / E = Rotate camera   |   R = Restart",
            hintStyle);

        // Win screen
        if (won)
        {
            Rect winRect = new Rect(
                0, Screen.height * 0.5f - 100f,
                Screen.width, 200f);

            DrawPanel(winRect);

            DrawText(
                winRect,
                "<size=60>YOU WIN!</size>\n" +
                "Time: " + elapsed.ToString("0.0") +
                " seconds\nPress R to play again",
                winStyle);
        }

        // Game Over screen
        if (gameOver)
        {
            Rect overRect = new Rect(
                0, Screen.height * 0.5f - 100f,
                Screen.width, 200f);

            DrawPanel(overRect);

            DrawText(
                overRect,
                "<size=60>GAME OVER!</size>\n" +
                "Time is up!\n" +
                "Coins: " + collected + " / " +
                totalCoins + "\n" +
                "Press R to try again",
                winStyle);
        }
    }

    static void DrawPanel(Rect rect)
    {
        Color old = GUI.color;
        GUI.color = new Color(0f, 0f, 0f, 0.75f);
        GUI.DrawTexture(rect, Texture2D.whiteTexture);
        GUI.color = old;
    }

    static void DrawText(
        Rect rect, string text, GUIStyle style)
    {
        Color original = style.normal.textColor;

        style.normal.textColor = Color.black;
        GUI.Label(
            new Rect(rect.x + 2f, rect.y + 2f,
                rect.width, rect.height),
            text, style);

        style.normal.textColor = original;
        GUI.Label(rect, text, style);
    }
}
